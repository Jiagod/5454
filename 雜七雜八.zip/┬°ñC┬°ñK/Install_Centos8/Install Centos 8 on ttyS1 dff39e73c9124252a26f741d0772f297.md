# Install Centos 8 on ttyS1

Outline

```
1. Make a usb centos 8 install disk with lunix dd 
2. Change boot device in Bios Menu and save
3. Choose the install ,  press “e” to edit the grub file
4. Add "console=ttyS1,115200n8"
5. Pres Ctrl+x to start the installation menu
6. Configure static IP for MGMT port
   Configure I210 to DHCP for access the internet (option)
7. Configure username/password

Ex: 
MGMT static IP 172.19.1.99
username/password: root/password
username/password: wnc/password
```

Change the boot device in Bios Menu

![Install%20Centos%208%20on%20ttyS1%20dff39e73c9124252a26f741d0772f297/Untitled.png](Install%20Centos%208%20on%20ttyS1%20dff39e73c9124252a26f741d0772f297/Untitled.png)

![Install%20Centos%208%20on%20ttyS1%20dff39e73c9124252a26f741d0772f297/Untitled%201.png](Install%20Centos%208%20on%20ttyS1%20dff39e73c9124252a26f741d0772f297/Untitled%201.png)

Choose "Install Centos" in grub menu and press "e" 

![Install%20Centos%208%20on%20ttyS1%20dff39e73c9124252a26f741d0772f297/Untitled%202.png](Install%20Centos%208%20on%20ttyS1%20dff39e73c9124252a26f741d0772f297/Untitled%202.png)

Change to "ttyS1,115200n8"

![Install%20Centos%208%20on%20ttyS1%20dff39e73c9124252a26f741d0772f297/Untitled%203.png](Install%20Centos%208%20on%20ttyS1%20dff39e73c9124252a26f741d0772f297/Untitled%203.png)

Then you will see  the installation menu.

![Install%20Centos%208%20on%20ttyS1%20dff39e73c9124252a26f741d0772f297/Untitled%204.png](Install%20Centos%208%20on%20ttyS1%20dff39e73c9124252a26f741d0772f297/Untitled%204.png)

Press '4'  to choose the install software.

![Install%20Centos%208%20on%20ttyS1%20dff39e73c9124252a26f741d0772f297/Untitled%205.png](Install%20Centos%208%20on%20ttyS1%20dff39e73c9124252a26f741d0772f297/Untitled%205.png)

![Install%20Centos%208%20on%20ttyS1%20dff39e73c9124252a26f741d0772f297/Untitled%206.png](Install%20Centos%208%20on%20ttyS1%20dff39e73c9124252a26f741d0772f297/Untitled%206.png)

Press '5' to choose the installation destination.

![Install%20Centos%208%20on%20ttyS1%20dff39e73c9124252a26f741d0772f297/Untitled%207.png](Install%20Centos%208%20on%20ttyS1%20dff39e73c9124252a26f741d0772f297/Untitled%207.png)

Press '7' to configure MGMT NIC 

![Install%20Centos%208%20on%20ttyS1%20dff39e73c9124252a26f741d0772f297/Untitled%208.png](Install%20Centos%208%20on%20ttyS1%20dff39e73c9124252a26f741d0772f297/Untitled%208.png)

Press '8' to configure  Root password

Press '9' to add an account

Press 'b' to start the installation

![Install%20Centos%208%20on%20ttyS1%20dff39e73c9124252a26f741d0772f297/Untitled%209.png](Install%20Centos%208%20on%20ttyS1%20dff39e73c9124252a26f741d0772f297/Untitled%209.png)

Wait the install complete. Press "Enter" to reboot.

![Install%20Centos%208%20on%20ttyS1%20dff39e73c9124252a26f741d0772f297/Untitled%2010.png](Install%20Centos%208%20on%20ttyS1%20dff39e73c9124252a26f741d0772f297/Untitled%2010.png)

Wait for login

![Install%20Centos%208%20on%20ttyS1%20dff39e73c9124252a26f741d0772f297/Untitled%2011.png](Install%20Centos%208%20on%20ttyS1%20dff39e73c9124252a26f741d0772f297/Untitled%2011.png)