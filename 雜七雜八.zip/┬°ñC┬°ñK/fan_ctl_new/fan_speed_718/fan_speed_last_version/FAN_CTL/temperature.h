#include <stdio.h>
#include <stdlib.h>
 char* temperature_array[] = {
                         "/sys/class/hwmon/hwmon1/temp1_input",
                         "/sys/class/hwmon/hwmon1/temp2_input",
                         "/sys/class/hwmon/hwmon1/temp3_input",
                         "/sys/class/hwmon/hwmon1/temp4_input",
                         "/sys/class/hwmon/hwmon1/temp5_input",
                         "/sys/class/hwmon/hwmon1/temp6_input",
                         "/sys/class/hwmon/hwmon1/temp7_input",
                         "/sys/class/hwmon/hwmon1/temp8_input",
                         "/sys/class/hwmoin/hwmon1/temp9_input",
                         "/sys/class/hwmon/hwmon1/temp10_nput",
                         "/sys/class/hwmon/hwmon1/temp11_input",
                         "/sys/class/hwmon/hwmon1/temp12_input",
                        "/sys/class/hwmon/hwmon1/temp13_input",
                        "/sys/class/hwmon/hwmon1/temp14_nput",
                         "/sys/class/hwmon/hwmon1/temp15_input",
                        "/sys/class/hwmon/hwmon1/temp16_input",
                        "/sys/class/hwmon/hwmon1/temp17_input",
			//"/sys/class/hwmon/hwmon1/temp18_input",
			//"/sys/class/hwmon/hwmon1/temp19_input",
			//"/sys/class/hwmon/hwmon1/temp20_input",
			//"/sys/class/hwmon/hwmon1/temp21_input",
			//"/sys/class/hwmon/hwmon2/temp22_input",
			 //"/sys/class/hwmon/hwmon2/temp23_input",
			 //"/sys/class/hwmon/hwmon2/temp24_input",
			 //"/sys/class/hwmon/hwmon2/temp25_input",
			 //"/sys/class/hwmon/hwmon2/temp26_input",
 			//"/sys/class/hwmon/hwmon2/temp27_input",
 			//"/sys/class/hwmon/hwmon2/temp28_input",
 			//"/sys/class/hwmon/hwmon2/temp29_input",
                         };



