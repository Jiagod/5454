#include<stdlib.h>
#include<stdio.h>
#include</root/fan_speed_last_version/FAN_CTL/temperature.h>
float get_max_temp(char** t_array){
        double value;
        int TEMP_IDX_MAX = sizeof(temperature_array);
        FILE *f;
        int i;
        double max_temp = 0;
        for(i=0 ; i < TEMP_IDX_MAX; i++){
                if((f = fopen(t_array[i], "r"))){
                        int temp = 0;
                        temp = fscanf(f, "%lf", &value);
                        if( max_temp < value ){
                                max_temp = value;
                        }
                        temp = fclose(f);
                }
        }
        i = 0;
        return max_temp;
}

void main(void){
	float temp;
	temp = (float)get_max_temp(temperature_array)/1000;
	printf("Temperature = %f\n",temp);
	return;
}
