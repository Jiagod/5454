#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
int MaxTemp_Get(void){
	FILE *fp1,*fp2;
	char cmd[100];
	char buffer[10];
	int size,i;
	float max = -1;
	snprintf(cmd,sizeof(cmd),"fpgainfo temp | cut -d ':' -f 2 | grep Celsius | wc -l | cut -d ' ' -f 2");
	fp1 = popen(cmd,"r");
	fgets(buffer,sizeof(buffer),fp1);
	size = atoi(buffer);
	float** tmp_array[size];
	
	for(i=0;i< size;i++){
		snprintf(cmd,sizeof(cmd),"fpgainfo temp | cut -d ':' -f 2 | grep Celsius | cut -d ' ' -f 2 | sed -n \'%dp\'",i+1);
		fp2 = popen(cmd,"r");
		tmp_array[i] = (int*)malloc(sizeof(int));
		fgets(tmp_array[i],sizeof(tmp_array[i]),fp2);
		if(atoi(tmp_array[i]) > max) max = atoi(tmp_array[i]);
		//printf("%d\n",atoi(tmp_array[i]));
		pclose(fp2);
	}
	for(i=0;i<size;i++){
		free(tmp_array[i]);
	}
	
	pclose(fp1);
	return max;
}
int main(void){
	float t;
	t = MaxTemp_Get();
	printf("MAX T=%f",t);
	return 0;
}
