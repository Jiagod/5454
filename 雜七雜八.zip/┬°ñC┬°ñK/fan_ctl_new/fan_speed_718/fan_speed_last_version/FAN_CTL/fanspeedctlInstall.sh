#!/bin/bash
cp fanspeed-ctl /usr/local/bin/
cp fanspeed-ctl.service /etc/systemd/system/
systemctl daemon-reload
systemctl start fanspeed-ctl.service
systemctl enable fanspeed-ctl.service
