#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#define TARGET_TEMPERATURE 60

struct _pid{
    float targettemp;       //target
    float curtemp;          // current temp
    float err;              // offset between target temp and current temp
    float err_last;        
    float kp,ki,kd;         
    float speed;            // control variable
    float integral;
}pid;

void PID_init(){
     pid.targettemp = 0.0;
     pid.curtemp = 0.0;
     pid.err = 0.0;
     pid.err_last = 0.0;
     pid.speed = 0.0;
     pid.integral = 0.0;
     pid.kp = 20;
     pid.ki = 0.8;
     pid.kd = 5;
}


//void PID_init(char** temp_array);
float PID_process(float target_temp, char* Busid);
char* getBusId(char *c);
char* dec2hex(char* hex,int dec);

int main(){
     char Busid[10], cmd_wakeup_fan[100];
     FILE *fp, *outfp;

     if(getBusId(Busid)){
    printf("Found the i2c adapter\n");
     }
     else{
    printf("Error: Can not foun i2c adapter\n");
    return 0;
     }
     
     snprintf(cmd_wakeup_fan,sizeof(cmd_wakeup_fan),"i2cset -y %s 0x70 0x20", Busid);
     //printf("Ini_cmd = %s\n", cmd_wakeup_fan);
     fp = popen(cmd_wakeup_fan,"r");
     fclose(fp);

     PID_init();
     //outfp = fopen("out.txt","w");
     //int i = 1000;
     while(1)
     {
         float temp = PID_process(TARGET_TEMPERATURE, Busid);
     //fprintf(outfp,"%f\n",speed);
         //printf("Temperature = %f\n",temp);
     //fflush(stdout);
         //i = i - 1;
     }
 return 0;
}


float  MaxT_get(void){
    FILE *fp1,*fp2;
        char cmd[200];
        char buffer[10];
        int size,i;
        float max = -1;
    
    snprintf(cmd,sizeof(cmd),"sensors | grep Core | cut -d ':' -f 2 | cut -d '(' -f 1 | wc -l");

        fp1 = popen(cmd,"r");
        fgets(buffer,sizeof(buffer),fp1);
        size = atoi(buffer);
        //printf("%d\n",size);
        float** tmp_array[size];

        for(i=0;i < size;i++){
    snprintf(cmd,sizeof(cmd),"sensors | grep Core | cut -d ':' -f 2 | cut -d '(' -f 1 | cut -d '+' -f 2 | cut -d '.' -f 1 | sed -n \'%dp\'",i+1);
        fp2 = popen(cmd,"r");
        tmp_array[i] = (int*)malloc(sizeof(int));
        fgets(tmp_array[i],sizeof(tmp_array[i]),fp2);
        if(atoi(tmp_array[i]) > max ) max = atoi(tmp_array[i]);
        //printf("%d\n", atoi(tmp_array[i]));
        pclose(fp2);

        }
        for(i=0;i<size;i++){
                free(tmp_array[i]);
        }

        //printf("MAX = %f",max);
        pclose(fp1);
        return max;
}

char* dec2hex(char* hex,int dec) {
        sprintf(hex, "%x", dec);
        //printf("hex = %s",hex);
        return hex;
}

float PID_process(float temp,char* id){
     FILE *fp1,*fp2,*fp3,*fp4,*fp5,*fp6;
     char cmd[100],hex[100],fan1[100],fan2[100],fan3[100],fan4[100],fan5[100],fan6[100];
     int speed;

    pid.targettemp = temp;
    pid.err = pid.targettemp - pid.curtemp;
    pid.integral += pid.err;
    pid.speed = pid.kp*pid.err + pid.ki*pid.integral + pid.kd*(pid.err - pid.err_last);
    pid.speed = -1 * pid.speed;
    //printf("Befor PID TEMP=%f\t",pid.speed);
    if(pid.speed <= 66){
        pid.speed = 66;
        pid.integral = 0;
        pid.err_last = 0;   
    }
    else if(pid.speed > 255){
        pid.speed = 255.0;
    }
    else{
        pid.err_last = pid.err;
    }
     speed = (int)pid.speed;
     //printf("Speed = %d ",speed);
     /**********generate command**********/
     dec2hex(hex,speed);
     snprintf(fan1,sizeof(fan1),"i2cset -y %s 0x66 0x00 0x%s",id, hex);
     snprintf(fan2,sizeof(fan2),"i2cset -y %s 0x66 0x01 0x%s",id, hex);
     snprintf(fan3,sizeof(fan3),"i2cset -y %s 0x66 0x02 0x%s",id, hex);
     snprintf(fan4,sizeof(fan4),"i2cset -y %s 0x66 0x03 0x%s",id, hex);
     snprintf(fan5,sizeof(fan5),"i2cset -y %s 0x66 0x04 0x%s",id, hex);
     snprintf(fan6,sizeof(fan6),"i2cset -y %s 0x66 0x05 0x%s",id, hex);

     /**********excute cmd**********/
     fp1 = popen(fan1, "r");
     fclose(fp1);
     fp2 = popen(fan2, "r");
     fclose(fp2);
     fp3 = popen(fan3, "r");
     fclose(fp3);
     fp4 = popen(fan4,"r");
     fclose(fp4);
     fp5 = popen(fan5,"r");
     fclose(fp5);
     fp6 = popen(fan6,"r");
     fclose(fp6);

     sleep(1);
     pid.curtemp = MaxT_get();
     //printf("TEMPUTRE = %d",(int)pid.curtemp);
     return (float)pid.curtemp;
}

char* getBusId(char *c){
    char id[2];
    FILE *fp;
    fp = popen("i2cdetect -l | grep \"I801\" | awk '{print $1}' | cut -d '-' -f 2", "r");
    fgets(id,sizeof(id),fp);
    strcpy(c,id);
    fclose(fp);
    return c;
}


